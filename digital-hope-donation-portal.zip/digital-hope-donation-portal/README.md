# Digital Hope — Rural School Computer Lab Donation Portal

A responsive frontend concept for a rural school hardware donation campaign, built using **HTML5 and CSS3 only**.

## Files
- `index.html` — page structure, school wishlists, pledge form, tracker, gallery
- `style.css` — responsive layout, colors, typography, hover states and mobile navigation

## Features
- Responsive landing page and navigation
- School wishlist cards showing student enrollment, working computers and hardware needs
- Donation pledge form with required fields and browser-native validation
- CSS-styled hardware refurbishment tracker
- Classroom photo showcase
- Mobile navigation using a CSS checkbox toggle
- Anchor navigation and CSS `:target` acknowledgement state

## Run locally
Open `index.html` in any modern browser. No build tools or dependencies are required.

## Important project limitation
This is a frontend-only demonstration. Since the project intentionally uses HTML and CSS without JavaScript or a backend:
- The pledge form does not transmit or save donor information.
- School data and tracker status are sample content written into the HTML.
- The tracker is a visual sample, not a live shipment tracker.
- Images and Google Fonts are loaded from external URLs and need an internet connection.

## GitHub Pages deployment
1. Create a public GitHub repository (for example, `digital-hope-donation-portal`).
2. Upload `index.html`, `style.css`, and this `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The deployed URL will appear in the Pages section.

## Academic note
Customize the school names, sample counts, images, colors or text to reflect your own understanding and be ready to explain the HTML structure, CSS layout, responsive breakpoints, form controls and CSS-only interactions during your viva.
